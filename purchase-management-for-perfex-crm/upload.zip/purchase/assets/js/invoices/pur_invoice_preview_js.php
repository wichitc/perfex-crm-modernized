<script >
$(function(){
  "use strict";

     var data_send_mail = {};
  <?php if(isset($send_mail_approve)){ 
    ?>
    data_send_mail = <?php echo json_encode($send_mail_approve); ?>;
    data_send_mail.rel_id = <?php echo pur_html_entity_decode($pur_invoice->id); ?>;
    data_send_mail.rel_type = 'purchase_invoice';
    data_send_mail.addedfrom = <?php echo ($pur_invoice->add_from_type == 'admin') ? pur_html_entity_decode($pur_invoice->add_from) : '""'; ?>;
    $.post(admin_url+'purchase/send_mail', data_send_mail).done(function(response){
    });
  <?php } ?>


   SignaturePad.prototype.toDataURLAndRemoveBlanks = function() {
     var canvas = this._ctx.canvas;
       // First duplicate the canvas to not alter the original
       var croppedCanvas = document.createElement('canvas'),
       croppedCtx = croppedCanvas.getContext('2d');

       croppedCanvas.width = canvas.width;
       croppedCanvas.height = canvas.height;
       croppedCtx.drawImage(canvas, 0, 0);

       // Next do the actual cropping
       var w = croppedCanvas.width,
       h = croppedCanvas.height,
       pix = {
         x: [],
         y: []
       },
       imageData = croppedCtx.getImageData(0, 0, croppedCanvas.width, croppedCanvas.height),
       x, y, index;

       for (y = 0; y < h; y++) {
         for (x = 0; x < w; x++) {
           index = (y * w + x) * 4;
           if (imageData.data[index + 3] > 0) {
             pix.x.push(x);
             pix.y.push(y);

           }
         }
       }
       pix.x.sort(function(a, b) {
         return a - b
       });
       pix.y.sort(function(a, b) {
         return a - b
       });
       var n = pix.x.length - 1;

       w = pix.x[n] - pix.x[0];
       h = pix.y[n] - pix.y[0];
       var cut = croppedCtx.getImageData(pix.x[0], pix.y[0], w, h);

       croppedCanvas.width = w;
       croppedCanvas.height = h;
       croppedCtx.putImageData(cut, 0, 0);

       return croppedCanvas.toDataURL();
     };


 function signaturePadChanged() {

   var input = document.getElementById('signatureInput');
   var $signatureLabel = $('#signatureLabel');
   $signatureLabel.removeClass('text-danger');

   if (signaturePad.isEmpty()) {
     $signatureLabel.addClass('text-danger');
     input.value = '';
     return false;
   }

   $('#signatureInput-error').remove();
   var partBase64 = signaturePad.toDataURLAndRemoveBlanks();
   partBase64 = partBase64.split(',')[1];
   input.value = partBase64;
 }

 var canvas = document.getElementById("signature");
 var signaturePad = new SignaturePad(canvas, {
  maxWidth: 2,
  onEnd:function(){
    signaturePadChanged();
  }
});

$('#identityConfirmationForm').submit(function() {
   signaturePadChanged();
 });


$('input[name="sign_type"]').on('click', function(){

  if($('#sign').is(':checked')){
    $('#sign_pad').removeClass('hide');
    $('#upload_sign').addClass('hide');
  }else if($('#upload').is(':checked')){
    $('#sign_pad').addClass('hide');
    $('#upload_sign').removeClass('hide');
  }

});


});

function send_request_approve(id){
  "use strict";
    var data = {};
    data.rel_id = <?php echo pur_html_entity_decode($pur_invoice->id); ?>;
    data.rel_type = 'purchase_invoice';
    data.addedfrom = <?php echo ($pur_invoice->add_from_type == 'admin') ? pur_html_entity_decode($pur_invoice->add_from) : '""'; ?>;
  $("body").append('<div class="dt-loader"></div>');
    $.post(admin_url + 'purchase/send_request_approve', data).done(function(response){
        response = JSON.parse(response);
        $("body").find('.dt-loader').remove();
        if (response.success === true || response.success == 'true') {
            alert_float('success', response.message);
            window.location.reload();
        }else{
          alert_float('warning', response.message);
            window.location.reload();
        }
    });
}

function signature_clear(){
"use strict";
var canvas = document.getElementById("signature");
var signaturePad = new SignaturePad(canvas, {
  maxWidth: 2,
  onEnd:function(){

  }
});
signaturePad.clear();

}
function sign_request(id){
  "use strict";
    

    if($('#upload').is(':checked')){
      if( document.getElementById("sign_attachment_file").files.length == 0 ){
         alert_float('success', '<?php echo _l('please_select_sign_image'); ?>');

         setTimeout(() => {
            $('#sign_button').removeAttr('disabled');
            $('#sign_button').removeClass('disabled');
            $('#sign_button').html('<?php echo _l('e_signature_sign') ?>');
          },"1000");

      }else{
        
        change_request_approval_status(id,2, true);

        $('#sign_attachment-form').submit();

      }
    }else if($('#sign').is(':checked')){

      change_request_approval_status(id,2, true);
    }
}
function approve_request(id){
  "use strict";
  change_request_approval_status(id,2);
  if( document.getElementById("sign_attachment_file").files.length > 0 ){
    $('#sign_attachment-form').submit();
  }
}
function deny_request(id){
  "use strict";
    change_request_approval_status(id,3);
    if( document.getElementById("sign_attachment_file").files.length > 0 ){
    $('#sign_attachment-form').submit();
  }
}
function change_request_approval_status(id, status, sign_code){
  "use strict";
    var data = {};
    data.rel_id = id;
    data.rel_type = 'purchase_invoice';
    data.approve = status;
    if(sign_code == true){
      data.signature = $('input[name="signature"]').val();

      if($('#sign').is(':checked')){
        data.sign_type = 'sign';
      }else if($('#upload').is(':checked')){
        data.sign_type = 'upload';
      }

    }else{
      data.note = $('textarea[name="reason"]').val();
    }
    $.post(admin_url + 'purchase/approve_request/' + id, data).done(function(response){
        response = JSON.parse(response); 
        if (response.success === true || response.success == 'true') {
            alert_float('success', response.message);

            if(sign_code != true || (sign_code == true && $('#sign').is(':checked'))){
              window.location.reload();
            }

        }
    });
}
function accept_action() {
  "use strict";
  $('#add_action').modal('show');
}


</script>